function out = art_paper_cut_process(image_in, thresh_degree)

image = image_in;
thresh = thresh_degree / 255;

image = gray_process(image, 4);

[h,w,z] = size(image);
for i = 1:1:h
    for j = 1:1:w
        if image(i,j,1) >= thresh
            image(i,j,:) = [1 0 0];
        else
            image(i,j,:) = [1 1 1];
        end
    end
end

out = image;