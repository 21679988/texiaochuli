function show_origin_image
%show the origin image
main_axes = getappdata(0,'magic_axes');
image = getappdata(0, 'process_image');
image = uint8(image * 255);

[h,w,z] = size(image);
max_width = 700;
max_height = 500;
if w > max_width
    w = max_width;
end

if h > max_height
    h = max_height;
end

if h < max_height;
    b = max_height - h;
else
    b = 0;
end

 
left = 0;
bottom = b;
width = w;
height = h;



set(main_axes, 'Units', 'Pixels');
set(main_axes,'Position', [left, bottom, width, height])
set(main_axes, 'Units', 'normalized');
axes(main_axes);
imshow(image);